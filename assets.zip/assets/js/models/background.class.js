import { MoveableObject } from "./movable-object.class.js";

export class Background extends MoveableObject {
  width = 720;
  height = 480;
  constructor(imgPath, x) {
    super();
    this.loadImage(imgPath);
    this.x = x;
    this.y = 480 - this.height;
  }
}
